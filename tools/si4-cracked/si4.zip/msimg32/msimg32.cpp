
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// ͷ�ļ�
#include "stdafx.h"
#include <Windows.h>
#include <stdio.h>
#include <WinCrypt.h>
#include "detours.h"
#include <shlwapi.h>

#include <wininet.h>

#pragma comment(lib,"Wininet.lib")

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// ��������
#pragma comment(linker, "/EXPORT:vSetDdrawflag=_AheadLib_vSetDdrawflag,@1")
#pragma comment(linker, "/EXPORT:AlphaBlend=_AheadLib_AlphaBlend,@2")
#pragma comment(linker, "/EXPORT:DllInitialize=_AheadLib_DllInitialize,@3")
#pragma comment(linker, "/EXPORT:GradientFill=_AheadLib_GradientFill,@4")
#pragma comment(linker, "/EXPORT:TransparentBlt=_AheadLib_TransparentBlt,@5")
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// �궨��
#define EXTERNC extern "C"
#define NAKED __declspec(naked)
#define EXPORT __declspec(dllexport)

#define ALCPP EXPORT NAKED
#define ALSTD EXTERNC EXPORT NAKED void __stdcall
#define ALCFAST EXTERNC EXPORT NAKED void __fastcall
#define ALCDECL EXTERNC NAKED void __cdecl
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


BOOL PatchBlackList(LPSTR pOrgInfo, DWORD cbInfo, LPDWORD newSize);
 

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// AheadLib �����ռ�
namespace AheadLib
{
	HMODULE m_hModule = NULL;	// ԭʼģ����
	DWORD m_dwReturn[5] = {0};	// ԭʼ�������ص�ַ
	DWORD m_tlsIdx = 0;


	// ����ԭʼģ��
	inline BOOL WINAPI Load()
	{
		TCHAR tzPath[MAX_PATH];
		TCHAR tzTemp[MAX_PATH * 2];

		GetSystemDirectory(tzPath, MAX_PATH);
		lstrcat(tzPath, TEXT("\\msimg32.dll"));
		m_hModule = LoadLibrary(tzPath);
		if (m_hModule == NULL)
		{
			wsprintf(tzTemp, TEXT("�޷����� %s�������޷��������С�"), tzPath);
			MessageBox(NULL, tzTemp, TEXT("AheadLib"), MB_ICONSTOP);
		}

		return (m_hModule != NULL);	
	}

	// �ͷ�ԭʼģ��
	inline VOID WINAPI Free()
	{
		if (m_hModule)
		{
			FreeLibrary(m_hModule);
		}
	}

	// ��ȡԭʼ������ַ
	FARPROC WINAPI GetAddress(PCSTR pszProcName)
	{
		FARPROC fpAddress;
		CHAR szProcName[16];
		TCHAR tzTemp[MAX_PATH];

		fpAddress = GetProcAddress(m_hModule, pszProcName);
		if (fpAddress == NULL)
		{
			if (HIWORD(pszProcName) == 0)
			{
				sprintf_s(szProcName, sizeof(szProcName), "%d", pszProcName);
				pszProcName = szProcName;
			}

			wsprintf(tzTemp, TEXT("�޷��ҵ����� %hs�������޷��������С�"), pszProcName);
			MessageBox(NULL, tzTemp, TEXT("AheadLib"), MB_ICONSTOP);
			ExitProcess(-2);
		}

		return fpAddress;
	}

	// Patch
	BOOL WINAPI Mine_CryptVerifySignatureW(HCRYPTHASH hHash, const BYTE *pbSignature, DWORD dwSigLen, HCRYPTKEY hPubKey, LPCWSTR szDescription, DWORD dwFlags)
	{
		return TRUE;
	}

	BOOL (WINAPI *Real_CryptVerifySignatureW)(HCRYPTHASH , const BYTE *, DWORD , HCRYPTKEY , LPCWSTR , DWORD ) = CryptVerifySignatureW;

	enum 
	{
		FACKED_FILE_HANDLE = -2
	};


	HANDLE (WINAPI *Real_CreateFileA)(LPCSTR lpFileName, DWORD dwDesiredAccess, 
		DWORD dwShareMode, LPSECURITY_ATTRIBUTES lpSecurityAttributes, DWORD dwCreationDisposition, DWORD dwFlagsAndAttributes, HANDLE hTemplateFile) = CreateFileA;

	HANDLE WINAPI Mine_CreateFileA(LPCSTR lpFileName, DWORD dwDesiredAccess, 
		DWORD dwShareMode, LPSECURITY_ATTRIBUTES lpSecurityAttributes, DWORD dwCreationDisposition, DWORD dwFlagsAndAttributes, HANDLE hTemplateFile)
	{
		LPCSTR lpName = PathFindFileNameA(lpFileName);
		if(lpName && !_stricmp(lpName, "si4update.dat")) 
		{
			if(dwCreationDisposition == OPEN_EXISTING)
			{
				// not exist
				return INVALID_HANDLE_VALUE;
			}
			HANDLE h = Real_CreateFileA(lpFileName, dwDesiredAccess, dwShareMode, lpSecurityAttributes, dwCreationDisposition, dwFlagsAndAttributes, hTemplateFile);
			TlsSetValue(m_tlsIdx, h);
			return h;
		}
		else
		{
			return Real_CreateFileA(lpFileName, dwDesiredAccess, dwShareMode, lpSecurityAttributes, dwCreationDisposition, dwFlagsAndAttributes, hTemplateFile);
		}
	}


	BOOL (WINAPI *Real_WriteFile)(HANDLE, LPCVOID, DWORD, LPDWORD, LPOVERLAPPED) = WriteFile;
	
	BOOL WINAPI Mine_WriteFile(HANDLE hFile, LPCVOID lpBuffer, DWORD nNumberOfBytesToWrite, LPDWORD lpNumberOfBytesWritten, LPOVERLAPPED lpOverlapped)
	{
		if((HANDLE)TlsGetValue(m_tlsIdx) == hFile)
		{
			DWORD newSize = 0;
			// Patch�������ػ����ĺ���������������Զ���ȡ������Ϣ�Ļ���InternetOpenW ֱ�����ص��ͺ���
			PatchBlackList((LPSTR)lpBuffer, nNumberOfBytesToWrite, &newSize);
			return Real_WriteFile(hFile, lpBuffer, newSize, lpNumberOfBytesWritten, lpOverlapped);;
		}
		return Real_WriteFile(hFile, lpBuffer, nNumberOfBytesToWrite, lpNumberOfBytesWritten, lpOverlapped);
	}

	BOOL (WINAPI *Real_CloseHandle)(HANDLE) = CloseHandle;

	BOOL WINAPI Mine_CloseHandle(HANDLE hObject)
	{
		if((HANDLE)TlsGetValue(m_tlsIdx) == hObject)
		{
			TlsSetValue(m_tlsIdx, INVALID_HANDLE_VALUE);
		}
		return Real_CloseHandle(hObject);
	}


	HINTERNET (WINAPI *Real_InternetOpenW)(LPCWSTR, DWORD, LPCWSTR, LPCWSTR, DWORD) = InternetOpenW;

	HINTERNET WINAPI Mine_InternetOpenW(LPCWSTR lpszAgent, DWORD dwAccessType, LPCWSTR lpszProxy, LPCWSTR lpszProxyBypass, DWORD dwFlags)
	{
		// ������Ȩ�Ķ�����������ϴ�������Ϣ��KEY��Ϣ�����KEY�ͻᱻ�Ӻ�
		if(!_wcsicmp(L"Source Insight", lpszAgent)) { return NULL; }

		// SourceInsight/4.0  ���UA������������UA

		return Real_InternetOpenW(lpszAgent, dwAccessType, lpszProxy, lpszProxyBypass, dwFlags);
	}


	LONG AttachDetours(VOID)
	{
		m_tlsIdx = TlsAlloc();
		if(TLS_OUT_OF_INDEXES == m_tlsIdx) { return 0;}

		DetourTransactionBegin();
		DetourUpdateThread(GetCurrentThread());

		DetourAttach(&(PVOID&)Real_CryptVerifySignatureW, Mine_CryptVerifySignatureW);
		DetourAttach(&(PVOID&)Real_CreateFileA, Mine_CreateFileA);
		DetourAttach(&(PVOID&)Real_WriteFile, Mine_WriteFile);
		DetourAttach(&(PVOID&)Real_CloseHandle, Mine_CloseHandle);
		DetourAttach(&(PVOID&)Real_InternetOpenW, Mine_InternetOpenW);

		return DetourTransactionCommit();
	}

	LONG DetachDetours(VOID)
	{
		TlsFree(m_tlsIdx);

		DetourTransactionBegin();
		DetourUpdateThread(GetCurrentThread());

		DetourDetach(&(PVOID&)Real_CryptVerifySignatureW, Mine_CryptVerifySignatureW);
		DetourDetach(&(PVOID&)Real_CreateFileA, Mine_CreateFileA);
		DetourDetach(&(PVOID&)Real_WriteFile, Mine_WriteFile);
		DetourDetach(&(PVOID&)Real_CloseHandle, Mine_CloseHandle);
		DetourDetach(&(PVOID&)Real_InternetOpenW, Mine_InternetOpenW);

		return DetourTransactionCommit();
	}
}
using namespace AheadLib;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// ��ں���
BOOL WINAPI DllMain(HMODULE hModule, DWORD dwReason, PVOID pvReserved)
{
	if (dwReason == DLL_PROCESS_ATTACH)
	{
		DisableThreadLibraryCalls(hModule);
		if(GetModuleHandle(TEXT("sourceinsight4.exe")))
		{
			AttachDetours();
		}
		return Load();
	}
	else if (dwReason == DLL_PROCESS_DETACH)
	{
		if(GetModuleHandle(TEXT("sourceinsight4.exe")))
		{
			DetachDetours();
		}
		Free();
	}

	return TRUE;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// ��������
ALCDECL AheadLib_vSetDdrawflag(void)
{
	GetAddress("vSetDdrawflag");
	__asm JMP EAX;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// ��������
ALCDECL AheadLib_AlphaBlend(void)
{
	GetAddress("AlphaBlend");
	__asm JMP EAX;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// ��������
ALCDECL AheadLib_DllInitialize(void)
{
	GetAddress("DllInitialize");
	__asm JMP EAX;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// ��������
ALCDECL AheadLib_GradientFill(void)
{
	GetAddress("GradientFill");
	__asm JMP EAX;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// ��������
ALCDECL AheadLib_TransparentBlt(void)
{
	GetAddress("TransparentBlt");
	__asm JMP EAX;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
